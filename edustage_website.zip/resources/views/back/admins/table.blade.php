<table id="datatable" class="table table-hover dt-responsive w-100 table-striped table-bordered">
    <thead class="table-light">                                
        <tr>
            <th>@lang('app.image')</th>
            <th>@lang('app.user')</th>
            <th>@lang('app.contact')</th>
            <th>@lang('app.last_login_time')</th>
            <th>@lang('app.gender')</th>
            <th>@lang('app.status')</th>
            <th>@lang('app.action')</th>
        </tr>
    </thead>
</table>
<table id="datatable" class="table table-hover dt-responsive w-100 table-striped table-bordered">
    <thead class="table-light">                                
        <tr>
            <th>ترتيب Faq</th>
            <th>عنوان Faq</th>
            <th>@lang('app.action')</th>
        </tr>
    </thead>
</table>
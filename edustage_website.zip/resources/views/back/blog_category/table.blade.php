<table id="datatable" class="table table-hover dt-responsive w-100 table-striped table-bordered">
    <thead class="table-light">                                
        <tr>
            <th>@lang('app.name')</th>
            <th>@lang('app.status')</th>
            <th>@lang('app.action')</th>
        </tr>
    </thead>
</table>
<table id="datatable" class="table table-hover dt-responsive w-100 table-striped table-bordered">
    <thead class="table-light">                                
        <tr>
            <th>@lang('app.app_name')</th>
            <th>@lang('app.phone')</th>
            <th>@lang('app.description')</th>
            <th>@lang('app.action')</th>
        </tr>
    </thead>
</table>